#!/bin/bash -l
#$ -N asopc_ew
#$ -j y
#$ -cwd
#$ -R y
#$ -pe smp 12
#$ -q standard.q
#$ -l mib=1
# #$ -l excl=1

./get_press > log.out
