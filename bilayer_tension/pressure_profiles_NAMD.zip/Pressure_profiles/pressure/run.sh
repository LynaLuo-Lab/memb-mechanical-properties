#!/bin/bash -l
./get_press > log.out
